unit Sorting;
  interface
  USES CRT, SYSUTILS, BubbleSort,InsertionSort;

  procedure sortFunction(sortType : CHAR; var UserArray : ARRAY OF STRING; lower, upper : LONGINT);

  IMPLEMENTATION

  PROCEDURE sortFunction(sortType : CHAR; var UserArray : ARRAY OF STRING; lower, upper : LONGINT);
    begin
      if sortType = 'I' THEN
        InsertionSort.InsertionSortFunction(UserArray, lower, upper)
      else if sortType = 'B' THEN
        BubbleSort.BubbleSortFunction(UserArray, lower, upper)
      else
        writeln('You are an idot. Put I or B.');
    end;

  END.
